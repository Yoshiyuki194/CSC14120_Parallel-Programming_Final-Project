We download [Eigen 3.3.4](http://bitbucket.org/eigen/eigen/get/3.3.4.tar.bz2) and unzip it here.
